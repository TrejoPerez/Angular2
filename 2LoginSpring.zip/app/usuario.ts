export class Usuario {
	idUsuario: number;
	nombre :string;
	email: string;
	password: string;

}