import { provideRouter, RouterConfig }  from '@angular/router';
import { HomeComponent } from './home.component';
import { UsuarioComponent } from './usuario.component';
import { BuscaIdComponent } from './buscaId.component';
const routes: RouterConfig = [
  
  {
    path:'usuario',
    component: UsuarioComponent
  },
  {
    path:'usuarioId',
    component:BuscaIdComponent
  },
  {
    path:'usuario/:id',
    component:BuscaIdComponent
  },
  {
    path:'home',
    component: HomeComponent
  },
  
  {
      path: '',
      redirectTo: 'home',
      pathMatch: 'full'
  }
  
];

export const appRouterProviders = [
  provideRouter(routes)
];