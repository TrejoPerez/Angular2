import { Component, EventEmitter,Input,OnInit,OnDestroy,Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Usuario } from './usuario';
import { UsuarioService } from './usuario.service';
@Component({
	selector:'my-usuario-id',
	templateUrl:'app/buscaId.component.html'
})
export class BuscaIdComponent {
	@Input()usuarios:Usuario[];
	state:boolean=false;
	id:any;
	constructor(private router: Router, private usuarioService: UsuarioService){}

	getId(){
		this.state=true;
		this.usuarioService.getId(this.id).subscribe(usuarios=>{
			this.usuarios = usuarios.json();
			console.log("encontrados=   "+ this.usuarios.length);
		});
		
	}	
}