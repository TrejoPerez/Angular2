import {Component, OnInit }  from '@angular/core';
import { Usuario } from './usuario';
import { UsuarioService } from './usuario.service';
import { Router } from '@angular/router';
@Component({
	selector:'my-home',
	templateUrl:'app/home.component.html'
	
	
})
export class HomeComponent {
	title = 'Seccion Botones';

}
