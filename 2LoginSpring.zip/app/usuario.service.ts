import { Injectable } from '@angular/core';
import { Headers, Http, Response,RequestOptions} from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { Usuario } from './usuario';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class UsuarioService {
	usuarioUrl='http://localhost:9000/usuariosP';
	//usuarioUrlId='http://localhost:9000/usuario/{id}';
	constructor(private http: Http){}
	getAll():Observable<Response>{
			return this.http.get(this.usuarioUrl);
	}
	getId(id:number):Observable<Response>{
		return this.http.get('http://localhost:9000/usuario/'+id);
		
	}
	
	private handleError(error: any){
		console.error('A ocurrido algo',error);
		return Promise.reject(error.message || error);
	}
		
}	