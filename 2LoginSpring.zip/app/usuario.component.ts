import { Component,Output } from '@angular/core';
import { Usuario } from './usuario';
import { UsuarioService} from './usuario.service';
import { Router } from '@angular/router';
import { OnInit } from '@angular/core';
@Component({
    selector: 'my-usuarios',
    templateUrl: 'app/usuario.component.html',    
})
export class UsuarioComponent implements OnInit{ 
	usuarios:Usuario[];
	error:any;
	constructor(private router: Router, private usuarioService: UsuarioService){}
	getAll(){
		this.usuarioService.getAll().subscribe(usuarios=>{
			this.usuarios = usuarios.json();
		});
	}
	ngOnInit(){
		this.getAll();
	}
}